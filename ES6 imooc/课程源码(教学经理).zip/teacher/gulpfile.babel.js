import requireDir from 'require-dir';

requireDir('./tasks');
