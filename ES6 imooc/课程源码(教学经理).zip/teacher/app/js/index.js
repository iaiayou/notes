import 'babel-polyfill';
import Lottery from './lottery';

const syy=new Lottery();
