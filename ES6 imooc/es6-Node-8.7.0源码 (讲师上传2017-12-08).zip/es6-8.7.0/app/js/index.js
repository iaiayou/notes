import 'babel-polyfill';
// import Lottery from './lottery';

// const syy=new Lottery();

// console.log(syy);
import './class/lesson11'
